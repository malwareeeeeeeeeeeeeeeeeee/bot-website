console.log("Project A1 is running 🚀");

function openGoogle() {
  window.open("https://www.google.com", "_blank");
}